# #postman
# config = {"authority": "https://login.microsoftonline.com/organizations",
#           "client_id": '0fea0036-0b22-4475-a7f9-001d771ffae2',
#           "username": "admin@m365x124493.onmicrosoft.com",
#           "password": "N0!is2Kn0w",
#           "scope": ["User.ReadBasic.All"],
#           "endpoint": "https://graph.microsoft.com/v1.0/users",
#           "client_secret": "d-C-EKM4.58FEi~0_M3~1d24KAuLk.qs6a"
#           }

# pygraph
config = {"authority": "https://login.microsoftonline.com/organizations",
          "client_id": 'dcdf039c-b816-4def-9d41-a807a1fa347c',
          "client_id_lic": "a2313ac6-2e79-47b4-92a8-619a6fbae005",
          "username": "@m365x124493.onmicrosoft.com",
          "password": "",
          "scope": ["User.ReadBasic.All", "User.ReadWrite.All"],
          "scope_lic": ["Organization.Read.All"],
          "endpoint": "https://graph.microsoft.com/v1.0/users",
          "apiurl": "https://graph.microsoft.com/v1.0",
          "client_secret": "Xrf2_7-9R~8P_73UrZeSAY.8L6D6~EIyfs",
          "client_secret_lic": "mjHipQ_G5.D~Bq-idQ38wJbxX63vy7-_bl"
          }
