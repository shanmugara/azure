# #postman

# users
# pygraph
app_secret = "Xrf2_7-9R~8P_73UrZeSAY.8L6D6~EIyfs"
cert_key_path = "/Users/speriya/PycharmProjects/azure/mykey.pem"
cert_path = "/Users/speriya/PycharmProjects/azure/mycert.cer"



config = {"authority": "https://login.microsoftonline.com/organizations",
          "client_id": 'dcdf039c-b816-4def-9d41-a807a1fa347c',
          "username": "role2@m365x124493.onmicrosoft.com",
          "password": b'Tk8xaXMya25vdw==',
          "scope": ["Directory.AccessAsUser.All", "Directory.ReadWrite.All", "User.ReadWrite.All",
                    "GroupMember.ReadWrite.All", "Reports.Read.All"],
          "apiurl": "https://graph.microsoft.com/v1.0",
          "client_secret": app_secret,
          "cert_auth": False,
          "proxy": None
          }

# licence
# pygraph
# config = {"authority": "https://login.microsoftonline.com/organizations",
#           "client_id": "a2313ac6-2e79-47b4-92a8-619a6fbae005",
#           "username": "role1@m365x124493.onmicrosoft.com",
#           "password": b'Tk8xaXMya25vdw==',
#           "scope": ["Organization.Read.All"],
#           "apiurl": "https://graph.microsoft.com/v1.0",
#           "client_secret": "mjHipQ_G5.D~Bq-idQ38wJbxX63vy7-_bl",
#           "proxy": None
#           }

# # pygraph 2
# config = {"authority": "https://login.microsoftonline.com/organizations",
#           "client_id": 'dcdf039c-b816-4def-9d41-a807a1fa347c',
#           "username": "admin@m365x124493.onmicrosoft.com",
#           "password": b'TjAhaXMyS24wdw==',
#           "scope": ["Directory.ReadWrite.All", "User.ReadWrite.All", "GroupMember.ReadWrite.All"],
#           "apiurl": "https://graph.microsoft.com/v1.0",
#           "client_secret": "Xrf2_7-9R~8P_73UrZeSAY.8L6D6~EIyfs",
#           "proxy": None
#           }
